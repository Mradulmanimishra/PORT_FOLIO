import React from 'react';
import { motion } from 'motion/react';
import { Fingerprint, Hand, Droplets, PenTool } from 'lucide-react';

const patents = [
  {
    title: 'SMART RING',
    icon: Fingerprint,
    status: 'Patent Pending',
    number: '2024110XXXXX',
    description: 'An IoT-based wearable device designed for seamless interaction with smart environments, featuring biometric authentication and gesture-based control interfaces.'
  },
  {
    title: 'GESTURE CONTROL SYSTEM',
    icon: Hand,
    status: 'Patent Pending',
    number: '2024110XXXXX',
    description: 'An advanced machine learning-driven system that recognizes complex hand gestures in real-time, enabling touchless interaction with digital displays and industrial machinery.'
  },
  {
    title: 'WATER STOPPER',
    icon: Droplets,
    status: 'Patent Pending',
    number: '2024110XXXXX',
    description: 'An automated water conservation system utilizing smart sensors and IoT connectivity to detect leaks and prevent wastage in residential and commercial plumbing systems.'
  },
  {
    title: 'GESTURE PEN',
    icon: PenTool,
    status: 'Patent Pending',
    number: '2024110XXXXX',
    description: 'A digital input innovation that translates physical writing movements into digital data, supporting high-precision design work and digital signature verification.'
  }
];

export const Patents = () => {
  return (
    <section id="patents" className="w-full py-20 px-8 bg-bg-base">
      <div className="max-w-[1400px] mx-auto">
        <div className="mb-16">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-white text-6xl mb-4"
          >
            INNOVATIONS & PATENTS
          </motion.h2>
          <p className="text-text-secondary font-sans text-xl tracking-widest uppercase">
            Filed via GLA University, Mathura • Intellectual Property Portfolio
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {patents.map((patent, index) => (
            <motion.div
              key={patent.title}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              whileHover={{ scale: 1.02, y: -5 }}
              className="bg-bg-elevated border border-border p-8 flex flex-col h-full group relative overflow-hidden transition-all duration-300 hover:border-accent"
            >
              <div className="absolute inset-0 bg-accent/5 opacity-0 group-hover:opacity-100 transition-opacity" />
              
              <div className="flex justify-between items-start mb-8">
                <patent.icon size={48} className="text-accent" />
                <div className="bg-accent/10 text-accent px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest border border-accent/20">
                  {patent.status}
                </div>
              </div>
              
              <h3 className="text-white text-2xl mb-2 tracking-widest font-display">
                {patent.title}
              </h3>
              
              <p className="text-accent font-mono text-[10px] mb-6 tracking-[2px]">
                APP NO: {patent.number}
              </p>

              <p className="text-text-secondary text-sm font-sans leading-relaxed">
                {patent.description}
              </p>
              
              <div className="mt-auto pt-8 flex items-center gap-2 text-accent font-display text-xs tracking-widest opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer">
                VIEW ABSTRACT <span>→</span>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
