import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { MessageSquare, X, Send, Bot, Sparkles, Brain } from 'lucide-react';
import { GoogleGenAI } from '@google/genai';
import { cn } from '../lib/utils';

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export const Chatbot = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<{ role: 'user' | 'ai', text: string }[]>([
    { role: 'ai', text: 'Hello! I am Mradul\'s AI assistant. How can I help you today?' }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isThinking, setIsThinking] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMsg = input.trim();
    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: userMsg }]);
    setIsLoading(true);

    try {
      const model = isThinking ? 'gemini-3.1-pro-preview' : 'gemini-3.1-flash-lite-preview';
      const response = await ai.models.generateContent({
        model,
        contents: userMsg,
        config: {
          systemInstruction: `You are a professional AI assistant for Mradul Mani Mishra, a Data Scientist and ML Engineer. 
          Your goal is to answer questions about his work, patents, and skills. 
          Keep responses concise, bold, and professional. 
          Mradul has 4 patents (Smart Ring, Gesture Control, Water Stopper, Gesture Pen).
          He specializes in Python, TensorFlow, and NLP.
          If asked about something unrelated, politely redirect to his professional work.`,
          tools: [{ googleSearch: {} }],
        }
      });

      setMessages(prev => [...prev, { role: 'ai', text: response.text || 'I apologize, I could not process that.' }]);
    } catch (error) {
      setMessages(prev => [...prev, { role: 'ai', text: 'Sorry, I encountered an error. Please try again.' }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
      <button 
        onClick={() => setIsOpen(true)}
        className="fixed bottom-8 right-8 z-[100] bg-accent text-white p-4 rounded-full red-glow hover:scale-110 transition-transform"
      >
        <MessageSquare size={24} />
      </button>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 100, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 100, scale: 0.9 }}
            className="fixed bottom-24 right-8 z-[100] w-[350px] md:w-[400px] bg-bg-elevated border border-accent shadow-2xl flex flex-col overflow-hidden"
          >
            {/* Header */}
            <div className="bg-accent p-4 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Bot size={24} className="text-white" />
                <div>
                  <h3 className="text-white font-display text-lg tracking-widest">AI ASSISTANT</h3>
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
                    <span className="text-white/70 text-[10px] uppercase font-mono tracking-tighter">Online</span>
                  </div>
                </div>
              </div>
              <button onClick={() => setIsOpen(false)} className="text-white hover:rotate-90 transition-transform">
                <X size={24} />
              </button>
            </div>

            {/* Messages */}
            <div ref={scrollRef} className="flex-1 h-[400px] overflow-y-auto p-4 space-y-4 no-scrollbar bg-bg-base">
              {messages.map((msg, i) => (
                <div key={i} className={cn(
                  "flex flex-col max-w-[85%]",
                  msg.role === 'user' ? "ml-auto items-end" : "items-start"
                )}>
                  <div className={cn(
                    "p-3 rounded-sm text-sm font-sans leading-relaxed",
                    msg.role === 'user' ? "bg-accent text-white" : "bg-bg-elevated border border-border text-text-secondary"
                  )}>
                    {msg.text}
                  </div>
                </div>
              ))}
              {isLoading && (
                <div className="flex items-center gap-2 text-accent">
                  <Loader2 size={16} className="animate-spin" />
                  <span className="text-xs font-mono uppercase tracking-widest">Thinking...</span>
                </div>
              )}
            </div>

            {/* Controls */}
            <div className="p-4 border-t border-border bg-bg-elevated space-y-4">
              <div className="flex items-center justify-between">
                <button 
                  onClick={() => setIsThinking(!isThinking)}
                  className={cn(
                    "flex items-center gap-2 px-3 py-1 rounded-full text-[10px] font-mono uppercase tracking-widest transition-all",
                    isThinking ? "bg-accent text-white" : "bg-bg-base text-text-muted border border-border"
                  )}
                >
                  <Brain size={12} /> {isThinking ? 'Thinking Mode ON' : 'Fast Mode'}
                </button>
                <div className="flex items-center gap-2 text-[10px] text-text-muted font-mono uppercase">
                  <Sparkles size={12} className="text-accent" /> Powered by Gemini
                </div>
              </div>
              
              <div className="flex gap-2">
                <input 
                  type="text" 
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                  placeholder="ASK ABOUT PATENTS..."
                  className="flex-1 bg-bg-base border border-border px-4 py-2 text-white text-sm focus:border-accent outline-none transition-colors"
                />
                <button 
                  onClick={handleSend}
                  disabled={isLoading}
                  className="bg-accent text-white p-2 hover:bg-accent-hover transition-colors disabled:opacity-50"
                >
                  <Send size={20} />
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};

const Loader2 = ({ size, className }: { size: number, className?: string }) => (
  <motion.div
    animate={{ rotate: 360 }}
    transition={{ repeat: Infinity, duration: 1, ease: 'linear' }}
    className={className}
  >
    <Bot size={size} />
  </motion.div>
);
