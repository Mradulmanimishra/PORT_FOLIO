import React, { useEffect, useState } from 'react';
import { motion, useScroll, useSpring } from 'motion/react';
import { Menu, X } from 'lucide-react';
import { cn } from '../lib/utils';

const navLinks = [
  { name: 'About', href: '#about' },
  { name: 'Experience', href: '#experience' },
  { name: 'Projects', href: '#projects' },
  { name: 'Patents', href: '#patents' },
  { name: 'Skills', href: '#skills' },
  { name: 'Contact', href: '#contact' },
];

export const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [activeSection, setActiveSection] = useState('');

  useEffect(() => {
    const handleScroll = () => {
      const sections = navLinks.map(link => link.href.substring(1));
      const current = sections.find(section => {
        const element = document.getElementById(section);
        if (element) {
          const rect = element.getBoundingClientRect();
          return rect.top <= 100 && rect.bottom >= 100;
        }
        return false;
      });
      if (current) setActiveSection(current);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <nav className="fixed top-0 left-0 w-full z-50 bg-bg-base/80 backdrop-blur-md border-b border-border">
      <div className="max-w-[1400px] mx-auto px-8 h-20 flex items-center justify-between">
        <a href="#hero" className="group flex items-center gap-2">
          <span className="font-display text-3xl text-accent group-hover:text-white transition-colors">MM</span>
        </a>

        {/* Desktop Menu */}
        <div className="hidden md:flex items-center gap-8">
          {navLinks.map((link) => (
            <a
              key={link.name}
              href={link.href}
              className={cn(
                "relative font-display text-lg tracking-widest transition-colors hover:text-accent",
                activeSection === link.href.substring(1) ? "text-accent" : "text-white"
              )}
            >
              {link.name}
              {activeSection === link.href.substring(1) && (
                <motion.div
                  layoutId="activeNav"
                  className="absolute -bottom-1 left-0 w-full h-[3px] bg-accent"
                />
              )}
            </a>
          ))}
        </div>

        <div className="hidden md:flex items-center gap-4">
          <a
            href="#"
            className="border border-accent text-accent font-display px-6 py-2 tracking-widest hover:bg-accent hover:text-white transition-all rounded-sm flex items-center gap-2"
          >
            RESUME
          </a>
          <a
            href="#contact"
            className="bg-accent text-white font-display px-6 py-2 tracking-widest hover:translate-y-[-4px] transition-transform rounded-sm"
          >
            HIRE ME
          </a>
        </div>

        {/* Mobile Toggle */}
        <button className="md:hidden text-white" onClick={() => setIsOpen(true)}>
          <Menu size={32} />
        </button>
      </div>

      {/* Mobile Menu Overlay */}
      {isOpen && (
        <motion.div
          initial={{ opacity: 0, x: '100%' }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: '100%' }}
          className="fixed inset-0 bg-bg-base z-[60] flex flex-col items-center justify-center gap-8"
        >
          <button className="absolute top-8 right-8 text-white" onClick={() => setIsOpen(false)}>
            <X size={40} />
          </button>
          {navLinks.map((link) => (
            <a
              key={link.name}
              href={link.href}
              onClick={() => setIsOpen(false)}
              className="font-display text-5xl text-white hover:text-accent flex items-center gap-4 group"
            >
              <span className="w-8 h-[2px] bg-accent scale-x-0 group-hover:scale-x-100 transition-transform origin-left" />
              {link.name}
            </a>
          ))}
        </motion.div>
      )}
    </nav>
  );
};

export const ScrollProgress = () => {
  const { scrollYProgress } = useScroll();
  const scaleY = useSpring(scrollYProgress, {
    stiffness: 100,
    damping: 30,
    restDelta: 0.001
  });

  return (
    <motion.div
      className="fixed right-0 top-0 bottom-0 w-1 bg-accent origin-top z-50"
      style={{ scaleY }}
    />
  );
};
