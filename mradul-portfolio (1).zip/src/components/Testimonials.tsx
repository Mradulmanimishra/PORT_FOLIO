import React from 'react';
import { motion } from 'motion/react';
import { Quote } from 'lucide-react';

const testimonials = [
  {
    quote: "Mradul's ability to translate complex data into actionable insights is unparalleled. His work on the MSD system was a game-changer for our research.",
    author: "Dr. Ajitesh Kumar",
    role: "Dy.Chief Proctor, Dept. of Computer Science, GLA University",
  },
  {
    quote: "A highly innovative engineer who doesn't just follow trends but creates them. The gesture control patent is a testament to his creative technical mind.",
    author: "Dr. Nikhil Govil",
    role: "Program Co-Ordinator, GLA University",
  },
  {
    quote: "Working with Mradul on Bookose was an incredible experience. His technical depth in both ML and Full Stack development is rare.",
    author: "Dr. Sabita Mam",
    role: "  EX-GLA University Member",
  }
];

export const Testimonials = () => {
  return (
    <section id="testimonials" className="w-full py-20 px-8 bg-bg-base">
      <div className="max-w-[1400px] mx-auto">
        <motion.h2 
          initial={{ opacity: 0, x: -30 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          className="text-white text-6xl mb-16"
        >
          TESTIMONIALS
        </motion.h2>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((t, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="bg-bg-elevated border border-border p-10 relative group hover:border-accent transition-colors"
            >
              <Quote className="text-accent mb-6 opacity-50 group-hover:opacity-100 transition-opacity" size={40} />
              <p className="text-text-secondary text-lg italic mb-8 leading-relaxed">
                "{t.quote}"
              </p>
              <div>
                <p className="text-white font-display text-xl tracking-widest">{t.author}</p>
                <p className="text-text-muted font-sans text-sm uppercase tracking-widest">{t.role}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
